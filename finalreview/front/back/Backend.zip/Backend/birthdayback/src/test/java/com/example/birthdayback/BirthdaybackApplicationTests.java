package com.example.birthdayback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BirthdaybackApplicationTests {

	@Test
	void contextLoads() {
	}

}
