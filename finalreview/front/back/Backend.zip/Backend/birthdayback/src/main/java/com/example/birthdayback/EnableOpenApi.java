package com.example.birthdayback;

public @interface EnableOpenApi {

}
